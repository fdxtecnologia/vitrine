local storyboard = require("storyboard");
local Urls = require("scripts.Utils.Urls");

function main()

	storyboard.gotoScene("scripts.home.HomeScene");
        
end

main();
